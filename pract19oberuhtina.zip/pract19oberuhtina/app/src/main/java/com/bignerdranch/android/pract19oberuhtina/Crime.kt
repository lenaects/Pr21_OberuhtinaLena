package com.bignerdranch.android.pract19oberuhtina

import java.util.*

data class Crime(var id: UUID = UUID.randomUUID()) {
    var title:String=""
    var date:Date=Date()
    var isSoled:Boolean=false
    constructor(id:UUID,title:String,date:Date=Date(),isSolover:Boolean):this(id){
        this.id=id
        this.title=title
        this.date=date
        this.isSoled=isSoled
    }
}